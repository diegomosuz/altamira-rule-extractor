PAQUETE CATHERINE CORREGIDO PARA ALTAMIRA RULE EXTRACTOR

Objetivo:
- conservar el programa CONSALDO y su logica funcional;
- evitar entradas ZIP de directorio;
- incluir DDL reales requeridos por el contrato del paquete;
- declarar CONSALDO como entry-program;
- expresar codigos de retorno con MOVE literal directo;
- separar ramas EVALUATE en decisiones IF independientes para que el detector
  actual genere un candidato por regla funcional.

Patrones de retorno esperados: 0000, 0001, 0002, 0003, 0004, 0005 y 9999.
El resultado generado por la aplicacion sigue requiriendo validacion funcional.
