       05 WS-TRF-ID                 PIC X(16).
       05 WS-ORIGEN-CUENTA          PIC X(16).
       05 WS-DESTINO-CUENTA         PIC X(16).
       05 WS-CLIENTE-ID             PIC X(12).
       05 WS-BENEF-ID               PIC X(12).
       05 WS-TIPO-TRF               PIC X.
          88 TRF-PROPIA             VALUE 'P'.
          88 TRF-TERCERO            VALUE 'T'.
          88 TRF-INTERNACIONAL      VALUE 'I'.
       05 WS-MONEDA                 PIC X(3).
       05 WS-MONTO                  PIC S9(11)V99 COMP-3.
       05 WS-COMISION               PIC S9(9)V99 COMP-3.
       05 WS-TOTAL-DEBITO           PIC S9(11)V99 COMP-3.
       05 WS-SALDO-DISP             PIC S9(11)V99 COMP-3.
       05 WS-ACUM-DIA               PIC S9(11)V99 COMP-3.
       05 WS-ACUM-MES               PIC S9(11)V99 COMP-3.
       05 WS-NUEVO-ACUM-DIA         PIC S9(11)V99 COMP-3.
       05 WS-NUEVO-ACUM-MES         PIC S9(11)V99 COMP-3.
       05 WS-LIMITE-TRF             PIC S9(11)V99 COMP-3.
       05 WS-LIMITE-DIA             PIC S9(11)V99 COMP-3.
       05 WS-LIMITE-MES             PIC S9(11)V99 COMP-3.
       05 WS-UMBRAL-MANUAL          PIC S9(11)V99 COMP-3.
       05 WS-RIESGO                 PIC 9(3).
       05 WS-ESTADO-ORIGEN          PIC X.
       05 WS-ESTADO-DESTINO         PIC X.
       05 WS-ESTADO-CLIENTE         PIC X.
       05 WS-BENEF-HABILITADO       PIC X.
       05 WS-PAIS-DESTINO           PIC X(3).
       05 WS-CODIGO-RETORNO         PIC S9(4) COMP.
          88 RC-OK                  VALUE 0.
          88 RC-CUENTA-NO-EXISTE    VALUE 101.
          88 RC-CUENTA-INACTIVA     VALUE 102.
          88 RC-MONTO-INVALIDO       VALUE 201.
          88 RC-LIMITE-EXCEDIDO      VALUE 202.
          88 RC-SALDO-INSUFICIENTE   VALUE 203.
          88 RC-RIESGO-ALTO          VALUE 301.
          88 RC-BENEF-NO-HABIL       VALUE 302.
          88 RC-PAIS-NO-ADM          VALUE 303.
          88 RC-REVISION-MANUAL      VALUE 350.
          88 RC-ERROR-SQL            VALUE 901.
       05 WS-ESTADO-PROCESO         PIC X.
          88 PROCESO-PENDIENTE      VALUE 'P'.
          88 PROCESO-APROBADO       VALUE 'A'.
          88 PROCESO-RECHAZADO      VALUE 'R'.
          88 PROCESO-MANUAL         VALUE 'M'.
