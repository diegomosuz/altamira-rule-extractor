       01 WS-CONTROL.
          05 WS-ERROR               PIC X VALUE 'N'.
             88 HAY-ERROR           VALUE 'S'.
          05 WS-REQUIERE-MANUAL     PIC X VALUE 'N'.
             88 REQUIERE-MANUAL     VALUE 'S'.
