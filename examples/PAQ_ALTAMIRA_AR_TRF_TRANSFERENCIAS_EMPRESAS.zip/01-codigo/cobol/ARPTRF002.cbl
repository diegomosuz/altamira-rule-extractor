       IDENTIFICATION DIVISION.
       PROGRAM-ID. ARPTRF002.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-SQLCODE                 PIC S9(9) COMP.
       01 WS-RIESGO-DB               PIC 9(3).
       01 WS-BENEF-DB                PIC X.

       LINKAGE SECTION.
       COPY ARCTRF001.

       PROCEDURE DIVISION USING WS-TRANSFERENCIA.
       0000-PRINCIPAL.
           PERFORM 1000-LEER-RIESGO
           IF WS-CODIGO-RETORNO = 0
              PERFORM 2000-LEER-BENEFICIARIO
           END-IF
           IF WS-CODIGO-RETORNO = 0
              PERFORM 3000-DECIDIR-RIESGO THRU 3900-FIN-RIESGO
           END-IF
           GOBACK.

       1000-LEER-RIESGO.
           EXEC SQL
              SELECT RIESGO
                INTO :WS-RIESGO-DB
                FROM TRF_CLIENTE_RIESGO
               WHERE CLIENTE_ID = :WS-CLIENTE-ID
           END-EXEC
           MOVE SQLCODE TO WS-SQLCODE
           IF WS-SQLCODE = 100
              MOVE 50 TO WS-RIESGO-DB
           END-IF
           IF WS-SQLCODE NOT = 0 AND WS-SQLCODE NOT = 100
              SET RC-ERROR-SQL TO TRUE
           END-IF
           MOVE WS-RIESGO-DB TO WS-RIESGO.

       2000-LEER-BENEFICIARIO.
           EXEC SQL
              SELECT HABILITADO
                INTO :WS-BENEF-DB
                FROM TRF_BENEFICIARIO
               WHERE CLIENTE_ID = :WS-CLIENTE-ID
                 AND BENEF_ID = :WS-BENEF-ID
           END-EXEC
           MOVE SQLCODE TO WS-SQLCODE
           IF WS-SQLCODE = 100
              MOVE 'N' TO WS-BENEF-HABILITADO
           ELSE
              MOVE WS-BENEF-DB TO WS-BENEF-HABILITADO
           END-IF.

       3000-DECIDIR-RIESGO.
           EVALUATE TRUE
              WHEN WS-RIESGO >= 90
                 SET RC-RIESGO-ALTO TO TRUE
                 SET PROCESO-RECHAZADO TO TRUE
              WHEN WS-RIESGO >= 70
                 SET RC-REVISION-MANUAL TO TRUE
                 SET PROCESO-MANUAL TO TRUE
              WHEN OTHER
                 CONTINUE
           END-EVALUATE.

       3100-VALIDAR-BENEFICIARIO.
           IF TRF-TERCERO AND WS-BENEF-HABILITADO NOT = 'S'
              SET RC-BENEF-NO-HABIL TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
           END-IF.

       3900-FIN-RIESGO.
           EXIT.
