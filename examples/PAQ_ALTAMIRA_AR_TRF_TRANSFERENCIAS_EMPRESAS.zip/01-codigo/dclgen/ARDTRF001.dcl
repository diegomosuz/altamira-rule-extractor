           EXEC SQL DECLARE TRF_CUENTA TABLE
           ( CUENTA_ID        CHAR(16) NOT NULL,
             CLIENTE_ID       CHAR(12) NOT NULL,
             ESTADO           CHAR(1)  NOT NULL,
             MONEDA           CHAR(3)  NOT NULL,
             SALDO_DISP       DECIMAL(13,2) NOT NULL,
             ACUM_DIA         DECIMAL(13,2) NOT NULL,
             ACUM_MES         DECIMAL(13,2) NOT NULL )
           END-EXEC.
       01 DCLTRF-CUENTA.
          05 DCL-CUENTA-ID           PIC X(16).
          05 DCL-CLIENTE-ID          PIC X(12).
          05 DCL-CUENTA-ESTADO       PIC X.
          05 DCL-CUENTA-MONEDA       PIC X(3).
          05 DCL-SALDO-DISP          PIC S9(11)V99 COMP-3.
          05 DCL-ACUM-DIA            PIC S9(11)V99 COMP-3.
          05 DCL-ACUM-MES            PIC S9(11)V99 COMP-3.
