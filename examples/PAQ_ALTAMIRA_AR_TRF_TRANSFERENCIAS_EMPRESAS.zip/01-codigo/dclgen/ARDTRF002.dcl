           EXEC SQL DECLARE TRF_TRANSFERENCIA TABLE
           ( TRF_ID           CHAR(16) NOT NULL,
             CUENTA_ORIGEN    CHAR(16) NOT NULL,
             CUENTA_DESTINO   CHAR(16) NOT NULL,
             MONTO            DECIMAL(13,2) NOT NULL,
             COMISION         DECIMAL(11,2) NOT NULL,
             ESTADO           CHAR(1) NOT NULL,
             COD_RETORNO      INTEGER NOT NULL )
           END-EXEC.
       01 DCLTRF-TRANSFERENCIA.
          05 DCL-TRF-ID              PIC X(16).
          05 DCL-TRF-ORIGEN          PIC X(16).
          05 DCL-TRF-DESTINO         PIC X(16).
          05 DCL-TRF-MONTO           PIC S9(11)V99 COMP-3.
          05 DCL-TRF-COMISION        PIC S9(9)V99 COMP-3.
          05 DCL-TRF-ESTADO          PIC X.
          05 DCL-TRF-COD-RET         PIC S9(4) COMP.
