PAQUETE SINTETICO CLIENTES EMPRESAS

5 programas COBOL, 15 reglas, 5 copybooks, 4 DCLGEN, 4 DDL,
4 snapshots CSV, 3 XML de repositorio, 2 XML de batch y manifest V1.
