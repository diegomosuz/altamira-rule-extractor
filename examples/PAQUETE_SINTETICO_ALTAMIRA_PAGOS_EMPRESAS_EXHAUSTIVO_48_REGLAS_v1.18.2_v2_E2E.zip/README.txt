PAQUETE SINTETICO ALTAMIRA - PAGOS EMPRESAS - EXHAUSTIVO 48 REGLAS - v2 E2E

Objetivo:
Fixture de estres semantico para FIERN / Altamira Rule Extractor v1.18.2.

Caracteristicas:
- 8 programas COBOL
- 10 copybooks .cpy usados por COPY/REPLACING
- 6 DCLGEN .dcl preservados como artefactos Altamira
- 7 EXEC SQL en programas COBOL: SELECT/INSERT/UPDATE/DELETE
- EXEC CICS LINK y RETURN
- IF, EVALUATE, WHEN, PERFORM, PERFORM THRU, GO TO, CALL
- Level-88
- RETURN_CODE, LEVEL_88_RETURN_CODE, RETURN_CODE_PROPAGATION,
  STATE_TRANSITION y CALCULATION
- Parametria DDL + snapshots
- Repositorio funcional y contexto batch/control-m

Correccion v2:
Los DCLGEN se mantienen en 01-codigo/dclgen pero NO son incorporados mediante
COPY en los programas ejecutables. Los COPY de los programas resuelven
exclusivamente copybooks .cpy de 01-codigo/copybooks.

Motivo:
La primera version del fixture mezclaba COPY COBOL con DCLGEN y produjo fallo
PARSED en tres programas. v2 elimina ese riesgo sin quitar DCLGEN del paquete.

Este fixture no debe reempaquetarse antes de cargarlo en FIERN.
