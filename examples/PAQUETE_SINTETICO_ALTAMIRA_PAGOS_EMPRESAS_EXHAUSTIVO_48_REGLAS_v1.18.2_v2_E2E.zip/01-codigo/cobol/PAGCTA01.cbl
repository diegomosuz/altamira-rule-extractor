       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGCTA01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGRETCP.
       COPY PAGDATCP.
       COPY PAGSQLCP.
       01 SQLCODE PIC S9(9) COMP VALUE 0.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-CONSULTAR-CLIENTE
           PERFORM 2000-CONSULTAR-CUENTA
           GOBACK.
       1000-CONSULTAR-CLIENTE.
           EXEC SQL
              SELECT ESTADO
                INTO :WS-ESTADO-CLIENTE
                FROM PAG_CLIENTE
               WHERE CLIENTE_ID = :WS-CLIENTE-ID
           END-EXEC
           EVALUATE SQLCODE
              WHEN 0
                 MOVE 'C100' TO WS-COD-RETORNO
              WHEN +100
                 MOVE 'C101' TO WS-COD-RETORNO
              WHEN OTHER
                 MOVE 'C199' TO WS-COD-RETORNO
           END-EVALUATE.
       2000-CONSULTAR-CUENTA.
           EXEC SQL
              SELECT ESTADO, SALDO_DISP
                INTO :WS-ESTADO-CUENTA, :WS-SALDO-DISPONIBLE
                FROM PAG_CUENTA
               WHERE CUENTA_ID = :WS-CUENTA-ID
           END-EXEC
           EVALUATE SQLCODE
              WHEN 0
                 MOVE 'C200' TO WS-COD-RETORNO
              WHEN +100
                 MOVE 'C201' TO WS-COD-RETORNO
              WHEN OTHER
                 MOVE 'C299' TO WS-COD-RETORNO
           END-EVALUATE.
