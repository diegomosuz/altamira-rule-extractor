       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGDB201.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGRETCP.
       COPY PAGDATCP.
       COPY PAGSQLCP.
       01 SQLCODE PIC S9(9) COMP VALUE 0.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-SELECT-OPERACION
           PERFORM 2000-INSERT-AUDITORIA
           PERFORM 3000-UPDATE-OPERACION
           PERFORM 4000-DELETE-TEMPORAL
           GOBACK.
       1000-SELECT-OPERACION.
           EXEC SQL
              SELECT ESTADO
                INTO :WS-ESTADO-CUENTA
                FROM PAG_OPERACION
               WHERE OPERACION_ID = :WS-OPERACION-ID
           END-EXEC
           IF SQLCODE NOT = 0
              MOVE 'D201' TO WS-COD-RETORNO
           END-IF.
       2000-INSERT-AUDITORIA.
           EXEC SQL
              INSERT INTO PAG_AUDITORIA
                     (OPERACION_ID, EVENTO, COD_RETORNO)
              VALUES (:WS-OPERACION-ID, 'VALIDACION',
                      :WS-COD-RETORNO)
           END-EXEC
           IF SQLCODE NOT = 0
              MOVE 'D202' TO WS-COD-RETORNO
           END-IF.
       3000-UPDATE-OPERACION.
           EXEC SQL
              UPDATE PAG_OPERACION
                 SET ESTADO = 'A'
               WHERE OPERACION_ID = :WS-OPERACION-ID
           END-EXEC
           IF SQLCODE NOT = 0
              MOVE 'D203' TO WS-COD-RETORNO
           END-IF.
       4000-DELETE-TEMPORAL.
           EXEC SQL
              DELETE FROM PAG_TEMPORAL
               WHERE OPERACION_ID = :WS-OPERACION-ID
           END-EXEC
           IF SQLCODE NOT = 0
              IF SQLCODE NOT = 100
                 MOVE 'D204' TO WS-COD-RETORNO
              END-IF
           END-IF.
