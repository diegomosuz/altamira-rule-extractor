       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGMST01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGRETCP.
       COPY PAGDATCP.
       COPY PAGCICCP.
       COPY PAGTMPCP REPLACING ==AAAA== BY ==WS-PAG==.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-VALIDAR-CANAL THRU 1600-FIN-VALIDAR
           IF WS-COD-RETORNO = SPACES
              PERFORM 2000-ENLAZAR-CUENTAS
           END-IF
           GO TO 9000-FIN.
       1000-VALIDAR-CANAL.
           IF WS-CANAL NOT = 'WEB' AND WS-CANAL NOT = 'API'
              MOVE 'M101' TO WS-COD-RETORNO
           END-IF.
       1100-VALIDAR-USUARIO.
           IF WS-USUARIO-AUT NOT = 'S'
              MOVE 'M102' TO WS-COD-RETORNO
           END-IF.
       1200-VALIDAR-IMPORTE.
           IF WS-IMPORTE <= 0
              MOVE 'M103' TO WS-COD-RETORNO
           END-IF.
       1300-VALIDAR-MONEDA.
           IF WS-MONEDA NOT = 'ARS' AND WS-MONEDA NOT = 'USD'
              MOVE 'M104' TO WS-COD-RETORNO
           END-IF.
       1400-VALIDAR-FECHA.
           IF WS-FECHA-VAL NOT = 'S'
              MOVE 'M105' TO WS-COD-RETORNO
           END-IF.
       1500-VALIDAR-CICS.
           EXEC CICS LINK
                PROGRAM  ('PAGCTA01')
                COMMAREA (WS-COMMAREA)
                LENGTH   (LENGTH OF WS-COMMAREA)
                RESP     (WS-CICS-RESP)
                RESP2    (WS-CICS-RESP2)
           END-EXEC
           IF WS-CICS-RESP NOT = 0
              MOVE '9999' TO WS-COD-RETORNO
           END-IF.
       1600-FIN-VALIDAR.
           EXIT.
       2000-ENLAZAR-CUENTAS.
           CALL 'PAGLIM01'
           CALL 'PAGRIE01'
           CALL 'PAGCOM01'
           CALL 'PAGDB201'.
       9000-FIN.
           EXEC CICS RETURN
           END-EXEC
           GOBACK.
