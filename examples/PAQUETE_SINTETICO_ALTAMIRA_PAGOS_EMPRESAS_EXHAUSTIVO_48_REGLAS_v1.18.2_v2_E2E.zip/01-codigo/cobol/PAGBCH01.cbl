       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGBCH01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGSTACP.
       COPY PAGBCHCP.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-RECIBIDO THRU 1600-FIN
           GOBACK.
       1000-RECIBIDO.
           IF WS-ARCHIVO-RECIBIDO = 'S'
              MOVE 'V' TO WS-ESTADO-OPERACION
           END-IF.
       1100-CUADRE.
           IF WS-TOTAL-CUADRA = 'S'
              MOVE 'A' TO WS-ESTADO-OPERACION
           END-IF.
       1200-CIERRE.
           IF WS-CIERRE-HABIL = 'S'
              MOVE 'L' TO WS-ESTADO-OPERACION
           END-IF.
       1300-CONCILIACION.
           IF WS-CONCILIADO = 'S'
              MOVE 'C' TO WS-ESTADO-OPERACION
           END-IF.
       1400-EXCEPCIONES.
           IF WS-EXCEPCIONES > 0
              MOVE 'O' TO WS-ESTADO-OPERACION
           END-IF.
       1500-REINTENTO.
           IF WS-REINTENTO-OK NOT = 'S'
              MOVE 'R' TO WS-ESTADO-OPERACION
           END-IF.
       1600-FIN.
           EXIT.
