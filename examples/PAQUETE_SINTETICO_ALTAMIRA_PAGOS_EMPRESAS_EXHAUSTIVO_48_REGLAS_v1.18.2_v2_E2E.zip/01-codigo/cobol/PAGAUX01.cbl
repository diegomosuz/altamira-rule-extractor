       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGAUX01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGRETCP.
       COPY PAGDATCP.
       COPY PAGSQLCP.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-PROPAGAR-01 THRU 1600-FIN
           GOBACK.
       1000-PROPAGAR-01.
           IF WS-CANAL = 'ATM'
              MOVE 'A101' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1100-PROPAGAR-02.
           IF WS-MONEDA = 'EUR'
              MOVE 'A102' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1200-PROPAGAR-03.
           IF WS-TIPO-PAGO = 'X'
              MOVE 'A103' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1300-PROPAGAR-04.
           IF WS-PRIORIDAD = 'Z'
              MOVE 'A104' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1400-PROPAGAR-05.
           IF WS-USUARIO-AUT = 'B'
              MOVE 'A105' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1500-PROPAGAR-06.
           IF WS-FECHA-VAL = 'N'
              MOVE 'A106' TO WS-COD-AUX
              MOVE WS-COD-AUX TO WS-COD-RETORNO
           END-IF.
       1600-FIN.
           EXIT.
