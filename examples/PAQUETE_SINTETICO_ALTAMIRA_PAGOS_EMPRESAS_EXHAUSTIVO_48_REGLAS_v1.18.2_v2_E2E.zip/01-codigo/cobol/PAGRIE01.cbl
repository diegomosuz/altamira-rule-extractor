       IDENTIFICATION DIVISION.
       PROGRAM-ID. PAGRIE01.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY PAGRETCP.
       COPY PAGRISCP.
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-RIESGO THRU 1600-FIN
           GOBACK.
       1000-RIESGO.
           IF WS-NIVEL-RIESGO > 80
              SET RC-RIESGO-ALTO TO TRUE
           END-IF.
       1100-RESTRINGIDA.
           IF WS-LISTA-RESTRINGIDA = 'S'
              SET RC-LISTA-RESTRINGIDA TO TRUE
           END-IF.
       1200-FIRMA.
           IF WS-FIRMA-VALIDA NOT = 'S'
              SET RC-FIRMA-INVALIDA TO TRUE
           END-IF.
       1300-SEGMENTO.
           IF WS-SEGMENTO = 'BLQ'
              SET RC-SEGMENTO-BLOQUEADO TO TRUE
           END-IF.
       1400-PEP.
           IF WS-ES-PEP = 'S'
              SET RC-PEP-REVISION TO TRUE
           END-IF.
       1500-SCORE.
           IF WS-SCORE < 600
              SET RC-SCORE-INSUFICIENTE TO TRUE
           END-IF.
       1600-FIN.
           EXIT.
