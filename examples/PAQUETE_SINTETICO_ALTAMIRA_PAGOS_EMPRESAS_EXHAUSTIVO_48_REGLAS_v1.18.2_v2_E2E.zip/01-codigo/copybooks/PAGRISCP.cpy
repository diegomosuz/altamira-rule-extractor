       01 WS-RIESGO-PAGO.
          05 WS-NIVEL-RIESGO       PIC 9(3) VALUE 10.
          05 WS-LISTA-RESTRINGIDA  PIC X VALUE 'N'.
          05 WS-FIRMA-VALIDA       PIC X VALUE 'S'.
          05 WS-SEGMENTO           PIC X(3) VALUE 'PYM'.
          05 WS-ES-PEP             PIC X VALUE 'N'.
          05 WS-SCORE              PIC 9(3) VALUE 850.
