       01 WS-SOLICITUD-PAGO.
          05 WS-CLIENTE-ID         PIC 9(9) VALUE 100001.
          05 WS-CUENTA-ID          PIC 9(12) VALUE 200000000001.
          05 WS-BENEFICIARIO-ID    PIC 9(9) VALUE 300001.
          05 WS-IMPORTE            PIC S9(11)V99 COMP-3 VALUE 1000.
          05 WS-MONEDA             PIC X(3) VALUE 'ARS'.
          05 WS-CANAL              PIC X(3) VALUE 'WEB'.
          05 WS-FECHA-VAL          PIC X VALUE 'S'.
          05 WS-USUARIO-AUT        PIC X VALUE 'S'.
          05 WS-TIPO-PAGO          PIC X VALUE 'N'.
          05 WS-PRIORIDAD          PIC X VALUE 'N'.
