       01 WS-CONTROL-BATCH.
          05 WS-ARCHIVO-RECIBIDO   PIC X VALUE 'S'.
          05 WS-TOTAL-CUADRA       PIC X VALUE 'S'.
          05 WS-CIERRE-HABIL       PIC X VALUE 'S'.
          05 WS-CONCILIADO         PIC X VALUE 'S'.
          05 WS-EXCEPCIONES        PIC 9(5) VALUE 0.
          05 WS-REINTENTO-OK       PIC X VALUE 'S'.
