       01 WS-AREA-CICS.
          05 WS-CICS-RESP          PIC S9(8) COMP VALUE 0.
          05 WS-CICS-RESP2         PIC S9(8) COMP VALUE 0.
          05 WS-COMMAREA           PIC X(256) VALUE SPACES.
