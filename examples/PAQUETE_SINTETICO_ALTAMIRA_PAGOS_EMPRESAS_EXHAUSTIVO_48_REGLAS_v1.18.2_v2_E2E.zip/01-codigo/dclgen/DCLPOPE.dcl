       EXEC SQL DECLARE PAG_OPERACION TABLE
          (
           OPERACION_ID DECIMAL(12,0),
           CUENTA_ID DECIMAL(12,0),
           IMPORTE DECIMAL(13,2),
           ESTADO CHAR(1)
          )
       END-EXEC.
