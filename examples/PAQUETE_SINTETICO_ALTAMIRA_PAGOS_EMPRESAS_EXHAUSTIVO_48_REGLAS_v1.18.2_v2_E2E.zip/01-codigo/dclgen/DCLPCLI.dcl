       EXEC SQL DECLARE PAG_CLIENTE TABLE
          (
           CLIENTE_ID INTEGER,
           ESTADO CHAR(1),
           SEGMENTO CHAR(3),
           SCORE INTEGER
          )
       END-EXEC.
