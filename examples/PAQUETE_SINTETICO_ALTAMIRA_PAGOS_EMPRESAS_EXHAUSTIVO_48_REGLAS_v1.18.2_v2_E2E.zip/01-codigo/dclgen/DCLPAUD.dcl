       EXEC SQL DECLARE PAG_AUDITORIA TABLE
          (
           OPERACION_ID DECIMAL(12,0),
           EVENTO CHAR(20),
           COD_RETORNO CHAR(4)
          )
       END-EXEC.
