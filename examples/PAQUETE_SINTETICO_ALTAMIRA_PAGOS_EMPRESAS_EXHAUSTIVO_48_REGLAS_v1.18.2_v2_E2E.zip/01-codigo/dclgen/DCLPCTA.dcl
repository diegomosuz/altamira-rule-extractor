       EXEC SQL DECLARE PAG_CUENTA TABLE
          (
           CUENTA_ID DECIMAL(12,0),
           CLIENTE_ID INTEGER,
           ESTADO CHAR(1),
           SALDO_DISP DECIMAL(13,2)
          )
       END-EXEC.
