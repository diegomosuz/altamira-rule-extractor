       EXEC SQL DECLARE PAG_TEMPORAL TABLE
          (
           OPERACION_ID DECIMAL(12,0),
           ESTADO CHAR(1),
           IMPORTE DECIMAL(13,2)
          )
       END-EXEC.
