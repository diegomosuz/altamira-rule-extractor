******************************************************************
      * PROGRAMA  : CONSALDO                                           *
      * TIPO      : ONLINE CICS                                         *
      * MODULO    : BANCA EMPRESARIAL                                   *
      * FUNCION   : CONSULTA DE SALDOS DE CUENTAS                       *
      * ESTANDAR  : ALTAMIRA COBOL - EMULADOR Z/OS                      *
      * AUTOR     : DESARROLLO BANCA EMPRESARIAL                        *
      * FECHA     : 2024                                                *
      ******************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CONSALDO.
      ******************************************************************
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-ZOS.
       OBJECT-COMPUTER. IBM-ZOS.
      ******************************************************************
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      ******************************************************************
      * AREA DE CONSTANTES Y LITERALES                                 *
      ******************************************************************
       01  WS-CONSTANTES.
           05  WS-PROGRAMA             PIC X(08) VALUE 'CONSALDO'.
           05  WS-FECHA-COMPILA        PIC X(08) VALUE '20240101'.

      ******************************************************************
      * AREA DE INDICADORES Y SWITCHES                                 *
      ******************************************************************
       01  WS-SWITCHES.
           05  SW-FIN-PROCESO          PIC X(01) VALUE 'N'.
               88  FIN-PROCESO                   VALUE 'S'.
               88  NO-FIN-PROCESO                VALUE 'N'.
           05  SW-ERROR                PIC X(01) VALUE 'N'.
               88  HAY-ERROR                     VALUE 'S'.
               88  NO-HAY-ERROR                  VALUE 'N'.
           05  SW-CLIENTE-OK           PIC X(01) VALUE 'N'.
               88  CLIENTE-EXISTE                VALUE 'S'.
               88  CLIENTE-NO-EXISTE             VALUE 'N'.
           05  SW-PRODUCTO-OK          PIC X(01) VALUE 'N'.
               88  PRODUCTO-ASOCIADO             VALUE 'S'.
               88  PRODUCTO-NO-ASOC              VALUE 'N'.

      ******************************************************************
      * AREA DE CODIGOS DE RETORNO Y MENSAJES                          *
      ******************************************************************
       01  WS-AREA-MENSAJES.
           05  WS-COD-RETORNO          PIC X(04) VALUE SPACES.
               88  COD-OK                        VALUE '0000'.
               88  COD-CLI-NO-EXISTE             VALUE '0001'.
               88  COD-PROD-NO-ASOC              VALUE '0002'.
               88  COD-PROD-INACTIVO             VALUE '0003'.
               88  COD-CTA-NO-EXISTE             VALUE '0004'.
               88  COD-CAMPO-INVALIDO            VALUE '0005'.
               88  COD-ERROR-BD                  VALUE '9999'.
           05  WS-MENSAJE-SALIDA       PIC X(80) VALUE SPACES.

      ******************************************************************
      * AREA DE TRABAJO PARA RESPUESTAS CICS                           *
      ******************************************************************
       01  WS-AREA-CICS.
           05  WS-RESP                 PIC S9(08) COMP VALUE ZEROS.
           05  WS-RESP2                PIC S9(08) COMP VALUE ZEROS.

      ******************************************************************
      * AREA DE COMUNICACION CON RUTINA DE CLIENTES                    *
      ******************************************************************
       01  WS-AREA-CLIENTES.
           05  WS-CLI-FUNCION          PIC X(02) VALUE SPACES.
               88  CLI-CONSULTAR                 VALUE 'CO'.
           05  WS-CLI-NUM-CLIENTE      PIC 9(10) VALUE ZEROS.
           05  WS-CLI-TIPO-DOC         PIC X(02) VALUE SPACES.
           05  WS-CLI-NUM-DOC          PIC X(15) VALUE SPACES.
           05  WS-CLI-NOMBRE           PIC X(40) VALUE SPACES.
           05  WS-CLI-ESTADO           PIC X(01) VALUE SPACES.
               88  CLI-ACTIVO                    VALUE 'A'.
               88  CLI-INACTIVO                  VALUE 'I'.
           05  WS-CLI-COD-RETORNO      PIC X(04) VALUE SPACES.
               88  CLI-RC-OK                     VALUE '0000'.
               88  CLI-RC-NO-EXISTE              VALUE '0001'.

      ******************************************************************
      * VARIABLES DE TRABAJO PARA VALIDACIONES                         *
      ******************************************************************
       01  WS-VARIABLES-TRABAJO.
           05  WS-CONTADOR             PIC 9(03) VALUE ZEROS.
           05  WS-SALDO-DISP           PIC S9(13)V99 COMP-3 VALUE ZEROS.
           05  WS-SALDO-CONTABLE       PIC S9(13)V99 COMP-3 VALUE ZEROS.
           05  WS-SALDO-RETENIDO       PIC S9(13)V99 COMP-3 VALUE ZEROS.

      ******************************************************************
      * COPYBOOK DE LA TABLA DB2 DE CUENTAS                            *
      ******************************************************************
           EXEC SQL INCLUDE SQLCA END-EXEC.

           EXEC SQL
               BEGIN DECLARE SECTION
           END-EXEC.

       01  WS-DCLCUENTAS.
           05  WS-DB2-NUM-CUENTA       PIC X(20).
           05  WS-DB2-NUM-CLIENTE      PIC S9(10) COMP-3.
           05  WS-DB2-COD-PRODUCTO     PIC X(04).
           05  WS-DB2-ESTADO-CTA       PIC X(01).
           05  WS-DB2-SALDO-DISP       PIC S9(13)V99 COMP-3.
           05  WS-DB2-SALDO-CONT       PIC S9(13)V99 COMP-3.
           05  WS-DB2-SALDO-RETEN      PIC S9(13)V99 COMP-3.
           05  WS-DB2-MONEDA           PIC X(03).

       01  WS-DCLPRODCLI.
           05  WS-DB2P-NUM-CLIENTE     PIC S9(10) COMP-3.
           05  WS-DB2P-COD-PRODUCTO    PIC X(04).
           05  WS-DB2P-ESTADO-PROD     PIC X(01).

           EXEC SQL
               END DECLARE SECTION
           END-EXEC.

      ******************************************************************
      * LINKAGE SECTION - AREA DE COMUNICACION (COMMAREA)              *
      ******************************************************************
       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  LK-ENTRADA.
               10  LK-NUM-CLIENTE      PIC 9(10).
               10  LK-COD-PRODUCTO     PIC X(04).
               10  LK-NUM-CUENTA       PIC X(20).
           05  LK-SALIDA.
               10  LK-COD-RETORNO      PIC X(04).
               10  LK-MENSAJE          PIC X(80).
               10  LK-NOMBRE-CLIENTE   PIC X(40).
               10  LK-MONEDA           PIC X(03).
               10  LK-SALDO-DISP       PIC S9(13)V99.
               10  LK-SALDO-CONTABLE   PIC S9(13)V99.
               10  LK-SALDO-RETENIDO   PIC S9(13)V99.

      ******************************************************************
       PROCEDURE DIVISION.
      ******************************************************************
       0000-PRINCIPAL.

           PERFORM 1000-INICIALIZAR

           IF NO-HAY-ERROR
              PERFORM 2000-VALIDAR-ENTRADA
           END-IF

           IF NO-HAY-ERROR
              PERFORM 3000-VALIDAR-CLIENTE
           END-IF

           IF NO-HAY-ERROR
              PERFORM 4000-VALIDAR-PRODUCTO
           END-IF

           IF NO-HAY-ERROR
              PERFORM 5000-CONSULTAR-SALDO
           END-IF

           PERFORM 9000-FINALIZAR

           EXEC CICS RETURN
           END-EXEC.

      ******************************************************************
      * RUTINA DE INICIALIZACION                                       *
      ******************************************************************
       1000-INICIALIZAR.

           INITIALIZE WS-AREA-MENSAJES
                      WS-VARIABLES-TRABAJO
                      WS-AREA-CLIENTES

           SET NO-HAY-ERROR        TO TRUE
           SET CLIENTE-NO-EXISTE   TO TRUE
           SET PRODUCTO-NO-ASOC    TO TRUE

      *--- VALIDAR QUE SE RECIBA COMMAREA ---*
           IF EIBCALEN = ZEROS
              SET HAY-ERROR        TO TRUE
              SET COD-CAMPO-INVALIDO TO TRUE
              MOVE 'NO SE RECIBIO AREA DE COMUNICACION'
                                   TO WS-MENSAJE-SALIDA
           ELSE
      *--- INICIALIZAR AREA DE SALIDA ---*
              MOVE SPACES          TO LK-COD-RETORNO
              MOVE SPACES          TO LK-MENSAJE
              MOVE SPACES          TO LK-NOMBRE-CLIENTE
              MOVE SPACES          TO LK-MONEDA
              MOVE ZEROS           TO LK-SALDO-DISP
              MOVE ZEROS           TO LK-SALDO-CONTABLE
              MOVE ZEROS           TO LK-SALDO-RETENIDO
           END-IF.

      ******************************************************************
      * VALIDACION DE CAMPOS DE ENTRADA                                *
      ******************************************************************
       2000-VALIDAR-ENTRADA.

      *--- VALIDAR NUMERO DE CLIENTE ---*
           IF LK-NUM-CLIENTE = ZEROS
              SET HAY-ERROR          TO TRUE
              SET COD-CAMPO-INVALIDO TO TRUE
              MOVE 'NUMERO DE CLIENTE OBLIGATORIO'
                                     TO WS-MENSAJE-SALIDA
           END-IF

      *--- VALIDAR CODIGO DE PRODUCTO ---*
           IF NO-HAY-ERROR
              IF LK-COD-PRODUCTO = SPACES OR LK-COD-PRODUCTO = LOW-VALUES
                 SET HAY-ERROR          TO TRUE
                 SET COD-CAMPO-INVALIDO TO TRUE
                 MOVE 'CODIGO DE PRODUCTO OBLIGATORIO'
                                        TO WS-MENSAJE-SALIDA
              END-IF
           END-IF

      *--- VALIDAR NUMERO DE CUENTA ---*
           IF NO-HAY-ERROR
              IF LK-NUM-CUENTA = SPACES OR LK-NUM-CUENTA = LOW-VALUES
                 SET HAY-ERROR          TO TRUE
                 SET COD-CAMPO-INVALIDO TO TRUE
                 MOVE 'NUMERO DE CUENTA OBLIGATORIO'
                                        TO WS-MENSAJE-SALIDA
              END-IF
           END-IF.

      ******************************************************************
      * VALIDAR EXISTENCIA DEL CLIENTE (LINK A RUTINA CLIENTES)        *
      ******************************************************************
       3000-VALIDAR-CLIENTE.

           SET CLI-CONSULTAR        TO TRUE
           MOVE LK-NUM-CLIENTE      TO WS-CLI-NUM-CLIENTE

      *--- INVOCAR RUTINA DEL MODULO DE CLIENTES ---*
           EXEC CICS LINK
                PROGRAM   ('RUTCLINF')
                COMMAREA  (WS-AREA-CLIENTES)
                LENGTH    (LENGTH OF WS-AREA-CLIENTES)
                RESP      (WS-RESP)
                RESP2     (WS-RESP2)
           END-EXEC

           IF WS-RESP NOT = DFHRESP(NORMAL)
              SET HAY-ERROR          TO TRUE
              SET COD-ERROR-BD       TO TRUE
              MOVE 'ERROR AL INVOCAR RUTINA DE CLIENTES'
                                     TO WS-MENSAJE-SALIDA
           ELSE
      *--- EVALUAR RESPUESTA DE LA RUTINA ---*
              EVALUATE TRUE
                 WHEN CLI-RC-OK
                      SET CLIENTE-EXISTE TO TRUE
                      MOVE WS-CLI-NOMBRE TO LK-NOMBRE-CLIENTE
                 WHEN CLI-RC-NO-EXISTE
                      SET HAY-ERROR          TO TRUE
                      SET COD-CLI-NO-EXISTE  TO TRUE
                      MOVE 'CLIENTE NO EXISTE EN BASE DE DATOS'
                                             TO WS-MENSAJE-SALIDA
                 WHEN OTHER
                      SET HAY-ERROR          TO TRUE
                      SET COD-ERROR-BD       TO TRUE
                      MOVE 'ERROR EN CONSULTA DE CLIENTE'
                                             TO WS-MENSAJE-SALIDA
              END-EVALUATE
           END-IF

      *--- VALIDAR ESTADO DEL CLIENTE ---*
           IF CLIENTE-EXISTE
              IF NOT CLI-ACTIVO
                 SET HAY-ERROR          TO TRUE
                 SET COD-CLI-NO-EXISTE  TO TRUE
                 MOVE 'CLIENTE SE ENCUENTRA INACTIVO'
                                        TO WS-MENSAJE-SALIDA
              END-IF
           END-IF.

      ******************************************************************
      * VALIDAR PRODUCTO ASOCIADO AL CLIENTE Y QUE ESTE ACTIVO         *
      ******************************************************************
       4000-VALIDAR-PRODUCTO.

           MOVE LK-NUM-CLIENTE      TO WS-DB2P-NUM-CLIENTE
           MOVE LK-COD-PRODUCTO     TO WS-DB2P-COD-PRODUCTO

           EXEC SQL
                SELECT  ESTADO_PROD
                  INTO  :WS-DB2P-ESTADO-PROD
                  FROM  PRODUCTO_CLIENTE
                 WHERE  NUM_CLIENTE  = :WS-DB2P-NUM-CLIENTE
                   AND  COD_PRODUCTO = :WS-DB2P-COD-PRODUCTO
           END-EXEC

           EVALUATE SQLCODE
              WHEN 0
                   SET PRODUCTO-ASOCIADO TO TRUE
      *--- VALIDAR QUE EL PRODUCTO ESTE ACTIVO ---*
                   IF WS-DB2P-ESTADO-PROD NOT = 'A'
                      SET HAY-ERROR        TO TRUE
                      SET COD-PROD-INACTIVO TO TRUE
                      MOVE 'PRODUCTO INACTIVO PARA EL CLIENTE'
                                           TO WS-MENSAJE-SALIDA
                   END-IF
              WHEN +100
                   SET HAY-ERROR        TO TRUE
                   SET COD-PROD-NO-ASOC TO TRUE
                   MOVE 'PRODUCTO NO ASOCIADO AL CLIENTE'
                                        TO WS-MENSAJE-SALIDA
              WHEN OTHER
                   SET HAY-ERROR        TO TRUE
                   SET COD-ERROR-BD     TO TRUE
                   MOVE 'ERROR EN CONSULTA PRODUCTO_CLIENTE'
                                        TO WS-MENSAJE-SALIDA
                   PERFORM 8000-LOG-ERROR-SQL
           END-EVALUATE.

      ******************************************************************
      * CONSULTAR SALDO EN BD DE CUENTAS INGRESANDO POR CLAVE          *
      ******************************************************************
       5000-CONSULTAR-SALDO.

           MOVE LK-NUM-CUENTA       TO WS-DB2-NUM-CUENTA
           MOVE LK-NUM-CLIENTE      TO WS-DB2-NUM-CLIENTE
           MOVE LK-COD-PRODUCTO     TO WS-DB2-COD-PRODUCTO

           EXEC SQL
                SELECT  NUM_CUENTA
                       ,ESTADO_CTA
                       ,SALDO_DISPONIBLE
                       ,SALDO_CONTABLE
                       ,SALDO_RETENIDO
                       ,MONEDA
                  INTO  :WS-DB2-NUM-CUENTA
                       ,:WS-DB2-ESTADO-CTA
                       ,:WS-DB2-SALDO-DISP
                       ,:WS-DB2-SALDO-CONT
                       ,:WS-DB2-SALDO-RETEN
                       ,:WS-DB2-MONEDA
                  FROM  CUENTAS
                 WHERE  NUM_CUENTA   = :WS-DB2-NUM-CUENTA
                   AND  NUM_CLIENTE  = :WS-DB2-NUM-CLIENTE
                   AND  COD_PRODUCTO = :WS-DB2-COD-PRODUCTO
           END-EXEC

           EVALUATE SQLCODE
              WHEN 0
                   PERFORM 5100-CARGAR-SALDOS
              WHEN +100
                   SET HAY-ERROR        TO TRUE
                   SET COD-CTA-NO-EXISTE TO TRUE
                   MOVE 'CUENTA NO EXISTE PARA EL CLIENTE/PRODUCTO'
                                        TO WS-MENSAJE-SALIDA
              WHEN OTHER
                   SET HAY-ERROR        TO TRUE
                   SET COD-ERROR-BD     TO TRUE
                   MOVE 'ERROR EN CONSULTA DE CUENTAS'
                                        TO WS-MENSAJE-SALIDA
                   PERFORM 8000-LOG-ERROR-SQL
           END-EVALUATE.

      ******************************************************************
      * CARGAR SALDOS EN AREA DE SALIDA                                *
      ******************************************************************
       5100-CARGAR-SALDOS.

           MOVE WS-DB2-SALDO-DISP   TO LK-SALDO-DISP
           MOVE WS-DB2-SALDO-CONT   TO LK-SALDO-CONTABLE
           MOVE WS-DB2-SALDO-RETEN  TO LK-SALDO-RETENIDO
           MOVE WS-DB2-MONEDA       TO LK-MONEDA

           SET COD-OK               TO TRUE
           MOVE 'CONSULTA EXITOSA'  TO WS-MENSAJE-SALIDA.

      ******************************************************************
      * LOG DE ERRORES SQL                                             *
      ******************************************************************
       8000-LOG-ERROR-SQL.

      *--- AQUI SE PUEDE INVOCAR RUTINA DE LOG / ABEND CONTROLADO ---*
      *--- SE GUARDA SQLCODE PARA TRAZABILIDAD                    ---*
           DISPLAY 'CONSALDO - ERROR SQLCODE: ' SQLCODE.

      ******************************************************************
      * FINALIZACION - CARGAR CODIGO DE RETORNO Y MENSAJE             *
      ******************************************************************
       9000-FINALIZAR.

           IF EIBCALEN > ZEROS
              MOVE WS-COD-RETORNO      TO LK-COD-RETORNO
              MOVE WS-MENSAJE-SALIDA   TO LK-MENSAJE
           END-IF.