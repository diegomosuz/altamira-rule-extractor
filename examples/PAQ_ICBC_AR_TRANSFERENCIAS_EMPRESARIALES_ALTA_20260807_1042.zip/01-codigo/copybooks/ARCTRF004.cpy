       01  WS-CONTROL.
           05  WS-ERROR              PIC X VALUE 'N'.
               88  HAY-ERROR         VALUE 'S'.
           05  WS-REQUIERE-MANUAL    PIC X VALUE 'N'.
               88  REQUIERE-MANUAL   VALUE 'S'.
           05  WS-PAIS-HABILITADO    PIC X VALUE 'N'.
               88  PAIS-HABILITADO   VALUE 'S'.
           05  WS-SQLCODE-AUX        PIC S9(9) COMP VALUE 0.
