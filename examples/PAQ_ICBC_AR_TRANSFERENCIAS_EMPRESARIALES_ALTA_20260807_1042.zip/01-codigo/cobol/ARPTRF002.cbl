       IDENTIFICATION DIVISION.
       PROGRAM-ID. ARPTRF002.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY ARDTRF002.
       COPY ARDTRF003.
       01  SQLCODE                    PIC S9(9) COMP VALUE 0.

       LINKAGE SECTION.
       COPY ARCTRF001.

       PROCEDURE DIVISION USING WS-TRANSFERENCIA.
       0000-PRINCIPAL.
           PERFORM 1000-LEER-RIESGO THRU 1900-FIN-LECTURA
           IF WS-CODIGO-RETORNO = 0
              PERFORM 2000-LEER-BENEFICIARIO
           END-IF
           IF WS-CODIGO-RETORNO = 0
              PERFORM 3000-DECIDIR-RIESGO THRU 3900-FIN-RIESGO
           END-IF
           GOBACK.

       1000-LEER-RIESGO.
           EXEC SQL
              SELECT RIESGO, ESTADO_CLIENTE
                INTO :WS-RIESGO, :WS-ESTADO-CLIENTE
                FROM TRF_CLIENTE_RIESGO
               WHERE CLIENTE_ID = :WS-CLIENTE-ID
           END-EXEC
           IF SQLCODE = 100
              MOVE 50 TO WS-RIESGO
              MOVE 'A' TO WS-ESTADO-CLIENTE
           END-IF
           IF SQLCODE NOT = 0 AND SQLCODE NOT = 100
              SET RC-ERROR-SQL TO TRUE
           END-IF.

       1900-FIN-LECTURA.
           EXIT.

       2000-LEER-BENEFICIARIO.
           IF TRF-TERCERO
              EXEC SQL
                 SELECT HABILITADO
                   INTO :WS-BENEF-HABILITADO
                   FROM TRF_BENEFICIARIO
                  WHERE CLIENTE_ID = :WS-CLIENTE-ID
                    AND BENEF_ID = :WS-BENEF-ID
              END-EXEC
              IF SQLCODE = 100
                 MOVE 'N' TO WS-BENEF-HABILITADO
              END-IF
              IF SQLCODE NOT = 0 AND SQLCODE NOT = 100
                 SET RC-ERROR-SQL TO TRUE
              END-IF
           END-IF.

       3000-DECIDIR-RIESGO.
           EVALUATE TRUE
              WHEN WS-ESTADO-CLIENTE = 'B'
                 SET RC-RIESGO-ALTO TO TRUE
                 SET PROCESO-RECHAZADO TO TRUE
              WHEN WS-RIESGO >= 90
                 SET RC-RIESGO-ALTO TO TRUE
                 SET PROCESO-RECHAZADO TO TRUE
              WHEN WS-RIESGO >= 70
                 SET RC-REVISION-MANUAL TO TRUE
                 SET PROCESO-MANUAL TO TRUE
              WHEN OTHER
                 CONTINUE
           END-EVALUATE.

       3200-VALIDAR-BENEFICIARIO.
           IF TRF-TERCERO AND WS-BENEF-HABILITADO NOT = 'S'
              SET RC-BENEF-NO-HABIL TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
           END-IF.

       3300-NORMALIZAR-RETORNO.
           IF PROCESO-APROBADO
              SET RC-OK TO TRUE
           END-IF.

       3900-FIN-RIESGO.
           EXIT.
