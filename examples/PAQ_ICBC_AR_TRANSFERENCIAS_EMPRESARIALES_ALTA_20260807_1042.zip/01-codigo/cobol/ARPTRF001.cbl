       IDENTIFICATION DIVISION.
       PROGRAM-ID. ARPTRF001.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY ARCTRF001.
       COPY ARCTRF003 REPLACING ==AAAA== BY ==WS-TRF==.
       COPY ARCTRF004.
       COPY ARDTRF001.
       COPY ARDTRF006.
       COPY ARDTRF007.
       COPY ARDTRF008.
       01  SQLCODE                    PIC S9(9) COMP VALUE 0.

       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-INICIALIZAR
           PERFORM 2000-CARGAR-DATOS THRU 2600-FIN-CARGA
           IF NOT HAY-ERROR
              PERFORM 3000-VALIDAR-NEGOCIO THRU 3900-FIN-VALIDAR
           END-IF
           IF NOT HAY-ERROR
              PERFORM 4000-CALCULAR-COMISION
           END-IF
           IF NOT HAY-ERROR
              PERFORM 5000-EVALUAR-RIESGO
           END-IF
           PERFORM 6000-PERSISTIR
           GO TO 9000-FIN-PROGRAMA.

       1000-INICIALIZAR.
           MOVE 0 TO WS-CODIGO-RETORNO
           MOVE 'N' TO WS-ERROR
           MOVE 'N' TO WS-REQUIERE-MANUAL
           MOVE 'N' TO WS-PAIS-HABILITADO
           SET PROCESO-PENDIENTE TO TRUE.

       2000-CARGAR-DATOS.
           EXEC SQL
              SELECT CLIENTE_ID, ESTADO, MONEDA, SALDO_DISP,
                     ACUM_DIA, ACUM_MES
                INTO :WS-CLIENTE-ID, :WS-ESTADO-ORIGEN, :WS-MONEDA,
                     :WS-SALDO-DISP, :WS-ACUM-DIA, :WS-ACUM-MES
                FROM TRF_CUENTA
               WHERE CUENTA_ID = :WS-ORIGEN-CUENTA
           END-EXEC
           MOVE SQLCODE TO WS-SQLCODE-AUX
           IF SQLCODE = 100
              SET RC-CUENTA-NO-EXISTE TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
              GO TO 2600-FIN-CARGA
           END-IF
           IF SQLCODE NOT = 0
              SET RC-ERROR-SQL TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
              GO TO 2600-FIN-CARGA
           END-IF.

       2100-CARGAR-DESTINO.
           EXEC SQL
              SELECT ESTADO
                INTO :WS-ESTADO-DESTINO
                FROM TRF_CUENTA
               WHERE CUENTA_ID = :WS-DESTINO-CUENTA
           END-EXEC
           IF SQLCODE = 100
              SET RC-CUENTA-NO-EXISTE TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF
           IF SQLCODE NOT = 0 AND SQLCODE NOT = 100
              SET RC-ERROR-SQL TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       2200-CARGAR-LIMITES.
           EXEC SQL
              SELECT LIMITE_TRF, LIMITE_DIA, LIMITE_MES, UMBRAL_MANUAL
                INTO :WS-LIMITE-TRF, :WS-LIMITE-DIA,
                     :WS-LIMITE-MES, :WS-UMBRAL-MANUAL
                FROM TRF_PARAM_LIMITES
               WHERE MONEDA = :WS-MONEDA
                 AND TIPO_TRF = :WS-TIPO-TRF
           END-EXEC
           IF SQLCODE NOT = 0
              SET RC-ERROR-SQL TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       2300-CARGAR-COMISION.
           EXEC SQL
              SELECT TASA
                INTO :WS-TRF-TASA-PROPIA
                FROM TRF_PARAM_COMISION
               WHERE MONEDA = :WS-MONEDA
                 AND TIPO_TRF = :WS-TIPO-TRF
           END-EXEC
           IF SQLCODE NOT = 0
              SET RC-ERROR-SQL TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF
           MOVE WS-TRF-TASA-PROPIA TO WS-TRF-TASA-TERCERO
           MOVE WS-TRF-TASA-PROPIA TO WS-TRF-TASA-INTERNAC.

       2400-VALIDAR-PAIS-SQL.
           IF TRF-INTERNACIONAL
              EXEC SQL
                 SELECT HABILITADO
                   INTO :WS-PAIS-HABILITADO
                   FROM TRF_PAISES
                  WHERE PAIS_COD = :WS-PAIS-DESTINO
              END-EXEC
              IF SQLCODE = 100
                 MOVE 'N' TO WS-PAIS-HABILITADO
              END-IF
              IF SQLCODE NOT = 0 AND SQLCODE NOT = 100
                 SET RC-ERROR-SQL TO TRUE
                 MOVE 'S' TO WS-ERROR
              END-IF
           END-IF.

       2500-COMPLETAR-CARGA.
           IF NOT HAY-ERROR
              PERFORM 2100-CARGAR-DESTINO
           END-IF
           IF NOT HAY-ERROR
              PERFORM 2200-CARGAR-LIMITES
           END-IF
           IF NOT HAY-ERROR
              PERFORM 2300-CARGAR-COMISION
           END-IF
           IF NOT HAY-ERROR
              PERFORM 2400-VALIDAR-PAIS-SQL
           END-IF.

       2600-FIN-CARGA.
           EXIT.

       3000-VALIDAR-NEGOCIO.
           IF WS-ORIGEN-CUENTA = WS-DESTINO-CUENTA
              SET RC-MONTO-INVALIDO TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
              GO TO 3900-FIN-VALIDAR
           END-IF.

       3100-VALIDAR-ESTADOS.
           IF WS-ESTADO-ORIGEN NOT = 'A'
              SET RC-CUENTA-INACTIVA TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF
           IF WS-ESTADO-DESTINO NOT = 'A'
              SET RC-CUENTA-INACTIVA TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       3200-VALIDAR-MONTO.
           IF WS-MONTO <= 0
              SET RC-MONTO-INVALIDO TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF
           IF WS-MONTO > WS-LIMITE-TRF
              SET RC-LIMITE-EXCEDIDO TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       3300-CALCULAR-ACUMULADOS.
           COMPUTE WS-NUEVO-ACUM-DIA = WS-ACUM-DIA + WS-MONTO
           COMPUTE WS-NUEVO-ACUM-MES = WS-ACUM-MES + WS-MONTO.

       3400-VALIDAR-ACUMULADOS.
           IF WS-NUEVO-ACUM-DIA > WS-LIMITE-DIA
              SET RC-LIMITE-EXCEDIDO TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF
           IF WS-NUEVO-ACUM-MES > WS-LIMITE-MES
              SET RC-LIMITE-EXCEDIDO TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       3500-VALIDAR-PAIS.
           IF TRF-INTERNACIONAL AND NOT PAIS-HABILITADO
              SET RC-PAIS-NO-ADM TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       3600-VALIDAR-MANUAL.
           IF WS-MONTO > WS-UMBRAL-MANUAL
              MOVE 'S' TO WS-REQUIERE-MANUAL
              SET RC-REVISION-MANUAL TO TRUE
              SET PROCESO-MANUAL TO TRUE
           END-IF.

       3700-CONSOLIDAR.
           IF NOT HAY-ERROR AND NOT REQUIERE-MANUAL
              SET RC-OK TO TRUE
              SET PROCESO-APROBADO TO TRUE
           END-IF.

       3800-ENLAZAR-DEPENDENCIAS.
           IF NOT HAY-ERROR
              PERFORM 3300-CALCULAR-ACUMULADOS
              PERFORM 3400-VALIDAR-ACUMULADOS
              PERFORM 3500-VALIDAR-PAIS
              PERFORM 3600-VALIDAR-MANUAL
              PERFORM 3700-CONSOLIDAR
           END-IF.

       3900-FIN-VALIDAR.
           EXIT.

       4000-CALCULAR-COMISION.
           EVALUATE TRUE
              WHEN TRF-PROPIA
                 COMPUTE WS-COMISION =
                         WS-MONTO * WS-TRF-TASA-PROPIA / 100
              WHEN TRF-TERCERO
                 COMPUTE WS-COMISION =
                         WS-MONTO * WS-TRF-TASA-TERCERO / 100
              WHEN TRF-INTERNACIONAL
                 COMPUTE WS-COMISION =
                         WS-MONTO * WS-TRF-TASA-INTERNAC / 100
              WHEN OTHER
                 MOVE 0 TO WS-COMISION
           END-EVALUATE
           COMPUTE WS-TOTAL-DEBITO = WS-MONTO + WS-COMISION
           IF WS-SALDO-DISP < WS-TOTAL-DEBITO
              SET RC-SALDO-INSUFICIENTE TO TRUE
              SET PROCESO-RECHAZADO TO TRUE
              MOVE 'S' TO WS-ERROR
           END-IF.

       5000-EVALUAR-RIESGO.
           CALL 'ARPTRF002'
             USING BY REFERENCE WS-TRANSFERENCIA
           IF WS-CODIGO-RETORNO NOT = 0
              MOVE 'S' TO WS-ERROR
           END-IF.

       6000-PERSISTIR.
           CALL 'ARPTRF003'
             USING BY REFERENCE WS-TRANSFERENCIA.

       9000-FIN-PROGRAMA.
           GOBACK.
